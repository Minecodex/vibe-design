const v = globalThis.process ?? { env: { NODE_ENV: "production" } }, l = "promptExtractor.session", d = "promptExtractor.job.", i = /* @__PURE__ */ new Map();
function f() {
  var e;
  return typeof chrome < "u" && ((e = chrome.storage) != null && e.local) ? chrome.storage.local : {
    async get(r) {
      return r ? Array.isArray(r) ? Object.fromEntries(r.map((a) => [a, i.get(a)])) : { [r]: i.get(r) } : Object.fromEntries(i.entries());
    },
    async set(r) {
      Object.entries(r).forEach(([a, t]) => i.set(a, t));
    },
    async remove(r) {
      (Array.isArray(r) ? r : [r]).forEach((t) => i.delete(t));
    }
  };
}
async function u() {
  const a = (await f().get(l))[l];
  if (!a || typeof a != "object")
    return null;
  const t = a;
  return !t.serverBaseUrl || !t.accessToken || !t.refreshToken ? null : {
    serverBaseUrl: t.serverBaseUrl,
    accessToken: t.accessToken,
    refreshToken: t.refreshToken
  };
}
async function h(e) {
  await f().set({
    [l]: e
  });
}
async function g() {
  await f().remove(l);
}
async function y(e) {
  await f().set({
    [`${d}${e.id}`]: e
  });
}
function m(e) {
  return e.trim().replace(/\/+$/, "").replace(/\/api\/v1$/i, "");
}
async function w() {
  const e = await u();
  if (!e)
    throw new Error("Missing session");
  const r = await fetch(
    `${m(e.serverBaseUrl)}/api/v1/auth/refresh`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        refresh_token: e.refreshToken
      })
    }
  );
  if (!r.ok)
    throw await g(), new Error("Refresh failed");
  const a = await r.json();
  return await h({
    ...e,
    accessToken: a.access_token,
    refreshToken: a.refresh_token
  }), a.access_token;
}
function b(e) {
  const [r, a] = e.split(",", 2);
  if (!r || !a)
    throw new Error("Invalid image data");
  const t = r.match(/^data:(.+);base64$/), n = (t == null ? void 0 : t[1]) || "image/png", o = atob(a), c = new Uint8Array(o.length);
  for (let s = 0; s < o.length; s += 1)
    c[s] = o.charCodeAt(s);
  return new Blob([c], { type: n });
}
function A(e) {
  return e === 401 || e === 403 ? "登录已失效，请重新登录" : e === 402 ? "余额不足" : e === 413 ? "图片过大" : "提取失败";
}
async function E(e, r) {
  const a = await u();
  if (!a)
    throw new Error("请先登录插件");
  const t = async (s) => {
    const p = new FormData();
    return p.append(
      "image",
      b(e),
      "prompt-extractor.png"
    ), p.append("locale", r), fetch(
      `${m(a.serverBaseUrl)}/api/v1/extension/prompt-extractor/analyze`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${s}`,
          "Accept-Language": r
        },
        body: p
      }
    );
  };
  let n = await t(a.accessToken);
  if (n.status === 401) {
    const s = await w();
    n = await t(s);
  }
  if (!n.ok)
    throw new Error(A(n.status));
  const o = await n.json(), c = o.amount_cents ?? o.amountCents ?? o.amount;
  return {
    prompt: o.prompt,
    prompts: o.prompts,
    language: o.language,
    model: o.model,
    amountCents: c
  };
}
function T(e) {
  let r = "";
  const a = new Uint8Array(e);
  for (let t = 0; t < a.byteLength; t += 1)
    r += String.fromCharCode(a[t]);
  return btoa(r);
}
async function x(e) {
  const r = await fetch(e);
  if (!r.ok)
    throw new Error("无法读取图片");
  const a = await r.blob(), t = await a.arrayBuffer();
  return `data:${a.type || "image/png"};base64,${T(t)}`;
}
function k(e) {
  if (!e || typeof e != "object")
    return !1;
  const r = e;
  return r.type === "prompt-extractor.extract-prompt" && typeof r.imageDataUrl == "string" && (r.locale === "zh-CN" || r.locale === "en-US");
}
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "prompt-extractor.extract",
    title: "提取提示词",
    contexts: ["image"]
  });
});
chrome.runtime.onMessage.addListener((e, r, a) => {
  if (k(e))
    return (async () => {
      try {
        const t = await E(e.imageDataUrl, e.locale);
        a({
          ok: !0,
          data: t
        });
      } catch (t) {
        a({
          ok: !1,
          error: t instanceof Error ? t.message : "提取失败"
        });
      }
    })(), !0;
});
chrome.contextMenus.onClicked.addListener(async (e, r) => {
  if (e.menuItemId !== "prompt-extractor.extract")
    return;
  if (!await u()) {
    chrome.runtime.openOptionsPage();
    return;
  }
  const t = typeof e.srcUrl == "string" ? e.srcUrl : "";
  if (!(!t || typeof (r == null ? void 0 : r.id) != "number"))
    try {
      const n = await x(t), o = navigator.language.startsWith("zh") ? "zh-CN" : "en-US", c = `job-${Date.now()}`;
      await y({
        id: c,
        imageDataUrl: n,
        locale: o
      }), await chrome.tabs.sendMessage(r.id, {
        type: "prompt-extractor.open-overlay",
        jobId: c
      });
    } catch {
      chrome.runtime.openOptionsPage();
    }
});
